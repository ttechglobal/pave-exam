import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/firebase";
import { doc, updateDoc } from "firebase/firestore";

export async function POST(req: NextRequest) {
  try {
    const { sessionId, section, answers } = await req.json();
    const ref = doc(db, "sessions", sessionId);
    await updateDoc(ref, {
      [`answers.${section}`]: answers,
    });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to save answer" }, { status: 500 });
  }
}