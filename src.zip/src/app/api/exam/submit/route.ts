import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/firebase";
import { doc, updateDoc, serverTimestamp } from "firebase/firestore";
 
export async function POST(req: NextRequest) {
  try {
    const { sessionId, autoSubmit } = await req.json();
    const ref = doc(db, "sessions", sessionId);
 
    await updateDoc(ref, {
      status: autoSubmit ? "timeout" : "submitted",
      submittedAt: serverTimestamp(),
    });
 
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json(
      { error: "Failed to submit exam" },
      { status: 500 }
    );
  }
}