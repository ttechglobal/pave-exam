import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

export async function POST(req: NextRequest) {
  try {
    const { personalDetails } = await req.json();

    const docRef = await addDoc(collection(db, "sessions"), {
      status: "active",
      startedAt: serverTimestamp(),
      submittedAt: null,
      timeRemaining: 3600,
      currentSection: 1,
      tabSwitchCount: 0,
      flags: [],
      personalDetails,
      answers: {
        section1: {},
        section2: {},
        section3: {},
      },
    });

    return NextResponse.json({ sessionId: docRef.id });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to start exam" }, { status: 500 });
  }
}