import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/firebase";
import { doc, updateDoc, arrayUnion, increment } from "firebase/firestore";

export async function POST(req: NextRequest) {
  try {
    const { sessionId, type, section } = await req.json();
    const ref = doc(db, "sessions", sessionId);
    await updateDoc(ref, {
      tabSwitchCount: increment(1),
      flags: arrayUnion({
        type,
        section,
        timestamp: Date.now(),
      }),
    });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to log flag" }, { status: 500 });
  }
}