"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useExamStore } from "@/store/examStore";
import { db } from "@/lib/firebase";
import { doc, updateDoc, increment } from "firebase/firestore";

export default function ExamLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const { timeRemaining, setTimeRemaining, sessionId, currentSection } = useExamStore();
  const [warningCount, setWarningCount] = useState(0);
  const [showWarning, setShowWarning] = useState(false);
  const [locked, setLocked] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // ── Timer ──────────────────────────────────────────────────
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setTimeRemaining(Math.max(0, timeRemaining - 1));
      if (timeRemaining <= 1) {
        clearInterval(timerRef.current!);
        handleAutoSubmit();
      }
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [timeRemaining]);

  const handleAutoSubmit = async () => {
    if (!sessionId) return;
    await fetch("/api/exam/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId, autoSubmit: true }),
    });
    router.push("/complete?reason=timeout");
  };

  // ── Tab Guard ──────────────────────────────────────────────
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) triggerWarning();
    };
    const handleBlur = () => triggerWarning();

    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("blur", handleBlur);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("blur", handleBlur);
    };
  }, [warningCount, sessionId, currentSection]);

  const triggerWarning = async () => {
    const newCount = warningCount + 1;
    setWarningCount(newCount);
    setShowWarning(true);

    if (sessionId) {
      await fetch("/api/admin/flag", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId,
          type: "tab_switch",
          section: currentSection,
        }),
      });
    }

    if (newCount >= 3) {
      setLocked(true);
      if (sessionId) {
        const ref = doc(db, "sessions", sessionId);
        await updateDoc(ref, { status: "locked" });
      }
    }
  };

  // ── Format time ────────────────────────────────────────────
  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  const isUrgent = timeRemaining <= 300; // last 5 minutes

  // ── Locked screen ──────────────────────────────────────────
  if (locked) {
    return (
      <div className="min-h-screen bg-red-50 flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="text-6xl mb-4">🔒</div>
          <h1 className="text-2xl font-bold text-red-700">Exam Locked</h1>
          <p className="text-red-600 mt-3 text-sm leading-relaxed">
            Your exam has been locked due to repeated tab switching violations.
            Please contact your exam invigilator immediately.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F7F9FC] flex flex-col">

      {/* Sticky top bar with timer */}
      <div className={`sticky top-0 z-50 w-full border-b shadow-sm px-6 py-3
        flex items-center justify-between
        ${isUrgent ? "bg-red-600 border-red-700" : "bg-[#003580] border-[#002a6b]"}`}>

        <div className="flex items-center gap-3">
          <span className="font-bold text-white text-sm">PAVE</span>
          <span className="text-blue-300">×</span>
          <span className="font-bold text-blue-200 text-sm">TAKK</span>
        </div>

        {/* Timer */}
        <div className="flex items-center gap-2">
          <span className="text-blue-200 text-xs uppercase tracking-wide">
            Time Remaining
          </span>
          <span className={`font-mono font-bold text-lg text-white 
            ${isUrgent ? "animate-pulse" : ""}`}>
            {formatTime(timeRemaining)}
          </span>
        </div>

        {/* Warning count */}
        <div className="flex items-center gap-2">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className={`w-2.5 h-2.5 rounded-full ${
                i <= warningCount ? "bg-red-400" : "bg-blue-400 opacity-30"
              }`}
            />
          ))}
          <span className="text-blue-200 text-xs ml-1">
            {warningCount}/3 warnings
          </span>
        </div>
      </div>

      {/* Warning Modal */}
      {showWarning && !locked && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center px-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center">
            <div className="text-5xl mb-4">⚠️</div>
            <h2 className="text-xl font-bold text-gray-900">
              Warning {warningCount} of 3
            </h2>
            <p className="text-gray-500 mt-3 text-sm leading-relaxed">
              You have switched tabs or left the exam window. This has been
              logged and reported to your invigilator.
            </p>
            {warningCount === 2 && (
              <p className="mt-3 text-red-600 text-sm font-semibold">
                One more violation will lock your exam permanently.
              </p>
            )}
            <button
              onClick={() => setShowWarning(false)}
              className="mt-6 w-full bg-[#003580] hover:bg-[#002a6b] text-white 
                font-semibold py-3 rounded-xl transition-all"
            >
              Return to Exam
            </button>
          </div>
        </div>
      )}

      {/* Page content */}
      <div className="flex-1">{children}</div>

    </div>
  );
}