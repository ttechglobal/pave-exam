"use client";
 
import { useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { useExamStore } from "@/store/examStore";
import { Suspense } from "react";
 
function CompleteContent() {
  const searchParams = useSearchParams();
  const reason = searchParams.get("reason");
  const { personalDetails, reset } = useExamStore();
  const isTimeout = reason === "timeout";
 
  // Clear local exam state after showing completion
  useEffect(() => {
    const timer = setTimeout(() => reset(), 5000);
    return () => clearTimeout(timer);
  }, []);
 
  return (
    <main className="min-h-screen bg-[#F7F9FC] flex flex-col items-center justify-center px-4">
      <div className="w-full max-w-lg text-center">
 
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mb-10">
          <span className="font-bold text-[#003580] text-lg">PAVE</span>
          <span className="text-gray-300 text-xl">×</span>
          <span className="font-bold text-[#005EB8] text-lg">TAKK</span>
        </div>
 
        {/* Icon */}
        <div className={`w-24 h-24 rounded-full flex items-center justify-center 
          mx-auto mb-6 text-5xl
          ${isTimeout ? "bg-amber-100" : "bg-green-100"}`}>
          {isTimeout ? "⏱️" : "✅"}
        </div>
 
        {/* Heading */}
        <h1 className={`text-3xl font-bold mb-3
          ${isTimeout ? "text-amber-700" : "text-green-700"}`}>
          {isTimeout ? "Time's Up" : "Exam Submitted"}
        </h1>
 
        {/* Subtext */}
        <p className="text-gray-500 text-base leading-relaxed mb-2">
          {isTimeout
            ? "Your exam time has expired. Your answers up to this point have been automatically saved and submitted."
            : `Thank you, ${personalDetails.firstName}. Your exam has been successfully submitted.`}
        </p>
 
        <p className="text-gray-400 text-sm leading-relaxed">
          The admissions team at TAKK will review your responses and be in
          touch with you via the email address provided.
        </p>
 
        {/* Info card */}
        <div className="mt-8 bg-white border border-gray-200 rounded-2xl p-6 text-left shadow-sm">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">
            What happens next?
          </h3>
          <ul className="space-y-3">
            {[
              "Your responses are now being reviewed by the TAKK admissions panel.",
              "You will receive a confirmation email at the address you provided.",
              "Successful candidates will be contacted within the stipulated timeframe.",
              "Do not attempt to retake the exam without official authorisation.",
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-3 text-sm text-gray-500">
                <span className="w-5 h-5 rounded-full bg-blue-50 border border-blue-200 
                  text-blue-600 text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                  {i + 1}
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>
 
        {/* Footer note */}
        <p className="mt-8 text-xs text-gray-400">
          © {new Date().getFullYear()} Pave x TAKK · FODA Vocational Qualification
        </p>
      </div>
    </main>
  );
}
 
export default function CompletePage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-400">Loading...</p>
      </div>
    }>
      <CompleteContent />
    </Suspense>
  );
}