import { NextRequest, NextResponse } from "next/server";
 
export function middleware(req: NextRequest) {
  const session = req.cookies.get("session")?.value;
  const isDashboard = req.nextUrl.pathname.startsWith("/dashboard");
 
  if (isDashboard && !session) {
    return NextResponse.redirect(new URL("/login", req.url));
  }
 
  return NextResponse.next();
}
 
export const config = {
  matcher: ["/dashboard/:path*"],
};