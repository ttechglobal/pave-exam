"use client";
 
import { useState } from "react";
import { useRouter } from "next/navigation";
import { auth } from "@/lib/firebase";
import { signInWithEmailAndPassword } from "firebase/auth";
 
export default function AdminLogin() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
 
  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      setError("Please enter your email and password.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await signInWithEmailAndPassword(auth, email, password);
      router.push("/dashboard");
    } catch (err: any) {
      setError("Invalid credentials. Please try again.");
    } finally {
      setLoading(false);
    }
  };
 
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleLogin();
  };
 
  return (
    <main className="min-h-screen bg-[#F7F9FC] flex flex-col items-center justify-center px-4">
      <div className="w-full max-w-md">
 
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mb-10">
          <span className="font-bold text-[#003580] text-xl">PAVE</span>
          <span className="text-gray-300 text-2xl">×</span>
          <span className="font-bold text-[#005EB8] text-xl">TAKK</span>
        </div>
 
        {/* Card */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-8">
 
          {/* Header */}
          <div className="mb-8">
            <span className="inline-block bg-blue-50 text-blue-700 text-xs font-semibold
              uppercase tracking-widest px-3 py-1.5 rounded-full border border-blue-100 mb-3">
              Admin Portal
            </span>
            <h1 className="text-2xl font-bold text-[#003580]">Invigilator Sign In</h1>
            <p className="text-gray-400 text-sm mt-1">
              Access the live exam monitoring dashboard.
            </p>
          </div>
 
          {/* Error */}
          {error && (
            <div className="mb-5 bg-red-50 border border-red-200 rounded-xl px-4 py-3
              text-sm text-red-600 flex items-center gap-2">
              <span>⚠️</span>
              {error}
            </div>
          )}
 
          {/* Fields */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                Email Address
              </label>
              <input
                type="email"
                placeholder="admin@pave.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={handleKeyDown}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm
                  outline-none bg-gray-50 focus:bg-white focus:ring-2
                  focus:ring-blue-500 focus:border-blue-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                Password
              </label>
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={handleKeyDown}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm
                  outline-none bg-gray-50 focus:bg-white focus:ring-2
                  focus:ring-blue-500 focus:border-blue-500 transition-all"
              />
            </div>
          </div>
 
          {/* Submit */}
          <button
            onClick={handleLogin}
            disabled={loading}
            className="mt-6 w-full bg-[#003580] hover:bg-[#002a6b] disabled:bg-gray-300
              text-white font-semibold text-base py-3.5 rounded-xl transition-all duration-200"
          >
            {loading ? "Signing in..." : "Sign In →"}
          </button>
        </div>
 
        {/* Footer */}
        <p className="text-center text-xs text-gray-400 mt-6">
          Restricted access · FODA Vocational Qualification Examination
        </p>
      </div>
    </main>
  );
}