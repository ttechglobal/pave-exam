"use client";

import { useRouter } from "next/navigation";
import Image from "next/image";

export default function LandingPage() {
  const router = useRouter();

  return (
    <main className="min-h-screen bg-[#F7F9FC] flex flex-col">

      {/* Header */}
      <header className="w-full bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          {/* Replace with real logos */}
          <div className="font-bold text-xl text-[#003580] tracking-tight">PAVE</div>
          <span className="text-gray-300 text-2xl font-light">×</span>
          <div className="font-bold text-xl text-[#005EB8] tracking-tight">TAKK</div>
        </div>
        <span className="text-xs text-gray-400 uppercase tracking-widest">
          Official Examination Portal
        </span>
      </header>

      {/* Hero */}
      <section className="flex-1 flex flex-col items-center justify-center px-4 py-20 text-center">

        {/* Badge */}
        <span className="inline-block bg-blue-50 text-blue-700 text-xs font-semibold 
          uppercase tracking-widest px-4 py-2 rounded-full mb-6 border border-blue-100">
          Vocational Qualification Examination
        </span>

        {/* Title */}
        <h1 className="text-4xl md:text-5xl font-bold text-[#003580] leading-tight max-w-3xl">
          FODA Vocational Qualification
          <span className="block text-[#005EB8]">
            in Cleaning & Property Services
          </span>
        </h1>

        <p className="mt-6 text-gray-500 text-lg max-w-xl leading-relaxed">
          This is an official qualifying examination for applicants seeking to
          study in Finland. Please read all instructions carefully before you begin.
        </p>

        {/* Exam Info Cards */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-3xl">
          {[
            { icon: "⏱️", label: "Duration", value: "60 Minutes" },
            { icon: "📋", label: "Sections", value: "3 Sections" },
            { icon: "📷", label: "Monitoring", value: "Webcam Required" },
            { icon: "🖥️", label: "Environment", value: "No Tab Switching" },
          ].map((item) => (
            <div
              key={item.label}
              className="bg-white rounded-xl border border-gray-200 p-4 
                flex flex-col items-center gap-2 shadow-sm"
            >
              <span className="text-2xl">{item.icon}</span>
              <span className="text-xs text-gray-400 uppercase tracking-wide">
                {item.label}
              </span>
              <span className="text-sm font-semibold text-gray-700">
                {item.value}
              </span>
            </div>
          ))}
        </div>

        {/* Important Notice */}
        <div className="mt-10 bg-amber-50 border border-amber-200 rounded-xl 
          p-6 max-w-2xl w-full text-left">
          <h3 className="font-semibold text-amber-800 mb-3 flex items-center gap-2">
            <span>⚠️</span> Important Notice Before You Begin
          </h3>
          <ul className="text-sm text-amber-700 space-y-2">
            <li>• This examination is monitored via webcam throughout the session.</li>
            <li>• Do not switch tabs, minimise or leave this window at any time.</li>
            <li>• Calculators and mobile phones are strictly not allowed.</li>
            <li>• You will receive <strong>3 warnings</strong> for violations — after which your exam will be locked.</li>
            <li>• Ensure you are in a quiet, well-lit environment before starting.</li>
            <li>• Once started, the 60-minute timer cannot be paused.</li>
          </ul>
        </div>

        {/* CTA */}
        <button
          onClick={() => router.push("/details")}
          className="mt-10 bg-[#003580] hover:bg-[#002a6b] text-white font-semibold 
            text-lg px-12 py-4 rounded-xl transition-all duration-200 shadow-lg 
            hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0"
        >
          Begin Application →
        </button>

        <p className="mt-4 text-xs text-gray-400">
          By proceeding, you agree to the examination terms and monitoring conditions.
        </p>
      </section>

      {/* Footer */}
      <footer className="w-full bg-white border-t border-gray-200 px-8 py-4 
        flex items-center justify-between text-xs text-gray-400">
        <span>© {new Date().getFullYear()} Pave x TAKK. All rights reserved.</span>
        <span>Powered by Pave Education</span>
      </footer>

    </main>
  );
}