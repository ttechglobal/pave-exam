"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useExamStore } from "@/store/examStore";
import type { PersonalDetails as PersonalDetailsType } from "@/types";

const fields = [
  { name: "familyName", label: "Family Name / Surname", type: "text", placeholder: "e.g. Johansson" },
  { name: "firstName", label: "First Name", type: "text", placeholder: "e.g. Maria" },
  { name: "age", label: "Age", type: "number", placeholder: "e.g. 28" },
  { name: "dateOfBirth", label: "Date of Birth", type: "date", placeholder: "" },
  { name: "nationality", label: "Nationality", type: "text", placeholder: "e.g. Nigerian" },
  { name: "email", label: "Email Address", type: "email", placeholder: "e.g. maria@email.com" },
] as const;

export default function PersonalDetails() {
  const router = useRouter();
  const { setPersonalDetails, setSessionId } = useExamStore();
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Partial<PersonalDetailsType>>({});

  const [form, setForm] = useState<PersonalDetailsType>({
    familyName: "", firstName: "", age: "",
    dateOfBirth: "", nationality: "", email: "",
  });

  const validate = (): boolean => {
    const newErrors: Partial<PersonalDetailsType> = {};
    if (!form.familyName.trim()) newErrors.familyName = "Family name is required";
    if (!form.firstName.trim()) newErrors.firstName = "First name is required";
    if (!form.age || isNaN(Number(form.age))) newErrors.age = "Valid age is required";
    if (!form.dateOfBirth) newErrors.dateOfBirth = "Date of birth is required";
    if (!form.nationality.trim()) newErrors.nationality = "Nationality is required";
    if (!form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) newErrors.email = "Valid email is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      const res = await fetch("/api/exam/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ personalDetails: form }),
      });
      const { sessionId } = await res.json();
      setPersonalDetails(form);
      setSessionId(sessionId);
      router.push("/exam/section-intro?section=1");
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-[#F7F9FC] flex flex-col items-center justify-center px-4 py-16">

      {/* Header */}
      <div className="w-full max-w-2xl mb-8">
        <div className="flex items-center gap-3 mb-6">
          <span className="font-bold text-[#003580] text-lg">PAVE</span>
          <span className="text-gray-300 text-xl">×</span>
          <span className="font-bold text-[#005EB8] text-lg">TAKK</span>
        </div>
        <h1 className="text-3xl font-bold text-[#003580]">Applicant Details</h1>
        <p className="text-gray-500 mt-2">
          Please fill in your personal information accurately before starting the exam.
        </p>
      </div>

      {/* Form Card */}
      <div className="w-full max-w-2xl bg-white rounded-2xl border border-gray-200 shadow-sm p-8">

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {fields.map((field) => (
            <div key={field.name} className={field.name === "email" ? "md:col-span-2" : ""}>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                {field.label}
              </label>
              <input
                type={field.type}
                placeholder={field.placeholder}
                value={form[field.name]}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, [field.name]: e.target.value }))
                }
                className={`w-full px-4 py-3 rounded-xl border text-sm outline-none
                  transition-all duration-150 bg-gray-50 focus:bg-white
                  focus:ring-2 focus:ring-blue-500 focus:border-blue-500
                  ${errors[field.name]
                    ? "border-red-400 focus:ring-red-400"
                    : "border-gray-200"
                  }`}
              />
              {errors[field.name] && (
                <p className="mt-1 text-xs text-red-500">{errors[field.name]}</p>
              )}
            </div>
          ))}
        </div>

        {/* Info box */}
        <div className="mt-8 bg-blue-50 border border-blue-100 rounded-xl p-4 text-sm text-blue-700">
          <strong>Before you proceed:</strong> Ensure your webcam is connected and
          your environment is quiet. The 60-minute timer begins immediately after
          you enter the exam.
        </div>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={loading}
          className="mt-8 w-full bg-[#003580] hover:bg-[#002a6b] disabled:bg-gray-300
            text-white font-semibold text-base py-4 rounded-xl transition-all duration-200"
        >
          {loading ? "Setting up your exam..." : "Proceed to Exam →"}
        </button>
      </div>
    </main>
  );
}