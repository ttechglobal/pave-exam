"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useExamStore } from "@/store/examStore";

const questions = [
  {
    key: "q1",
    question: "You have 9 pens and buy 4 more. How many pens do you have in total?",
    options: [
      { id: "A", text: "11" },
      { id: "B", text: "13" },
      { id: "C", text: "12" },
      { id: "D", text: "14" },
    ],
    answer: "B",
  },
  {
    key: "q2",
    question:
      "There are 31 apples in a basket. Lisa takes 13 apples. How many apples are left in the basket?",
    options: [
      { id: "A", text: "18" },
      { id: "B", text: "17" },
      { id: "C", text: "21" },
      { id: "D", text: "16" },
    ],
    answer: "A",
  },
  {
    key: "q3",
    question:
      "Lisa has 4 dogs and 2 cats. Each of these animals has 4 legs. How many legs do the animals have altogether?",
    options: [
      { id: "A", text: "20" },
      { id: "B", text: "22" },
      { id: "C", text: "24" },
      { id: "D", text: "18" },
    ],
    answer: "C",
  },
  {
    key: "q4",
    question: "Look at the series: 2, 4, 6, 8, ___. What number comes next?",
    options: [
      { id: "A", text: "9" },
      { id: "B", text: "10" },
      { id: "C", text: "11" },
      { id: "D", text: "12" },
    ],
    answer: "B",
  },
  {
    key: "q5",
    question:
      "A cleaner works 8 hours a day, 5 days a week. How many hours does she work per week?",
    options: [
      { id: "A", text: "35" },
      { id: "B", text: "45" },
      { id: "C", text: "40" },
      { id: "D", text: "42" },
    ],
    answer: "C",
  },
  {
    key: "q6",
    question:
      "A bottle holds 500ml of cleaning liquid. How many bottles are needed to fill a 2-litre container?",
    options: [
      { id: "A", text: "3" },
      { id: "B", text: "5" },
      { id: "C", text: "2" },
      { id: "D", text: "4" },
    ],
    answer: "D",
  },
  {
    key: "q7",
    question: "Look at the series: 1, 3, 9, 27, ___. What number comes next?",
    options: [
      { id: "A", text: "54" },
      { id: "B", text: "81" },
      { id: "C", text: "72" },
      { id: "D", text: "63" },
    ],
    answer: "B",
  },
  {
    key: "q8",
    question:
      "A cleaning product costs €3.50 per bottle. You buy 4 bottles. How much do you pay in total?",
    options: [
      { id: "A", text: "€13.00" },
      { id: "B", text: "€14.50" },
      { id: "C", text: "€14.00" },
      { id: "D", text: "€12.50" },
    ],
    answer: "C",
  },
  {
    key: "q9",
    question:
      "A room is 6 metres long and 4 metres wide. What is the area of the room?",
    options: [
      { id: "A", text: "20m²" },
      { id: "B", text: "22m²" },
      { id: "C", text: "26m²" },
      { id: "D", text: "24m²" },
    ],
    answer: "D",
  },
  {
    key: "q10",
    question:
      "Look at the series: 50, 45, 40, 35, ___. What number comes next?",
    options: [
      { id: "A", text: "28" },
      { id: "B", text: "25" },
      { id: "C", text: "30" },
      { id: "D", text: "32" },
    ],
    answer: "C",
  },
  {
    key: "q11",
    question:
      "A cleaner uses ¼ of a bottle of soap per room. How many rooms can be cleaned with 3 full bottles?",
    options: [
      { id: "A", text: "10" },
      { id: "B", text: "14" },
      { id: "C", text: "8" },
      { id: "D", text: "12" },
    ],
    answer: "D",
  },
] as const;

type QuestionKey = (typeof questions)[number]["key"];

export default function Section3() {
  const router = useRouter();
  const { updateSection3, section3, sessionId } = useExamStore();
  const [errors, setErrors] = useState<Partial<Record<QuestionKey, string>>>({});
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors: Partial<Record<QuestionKey, string>> = {};
    questions.forEach(({ key }) => {
      if (!section3[key]) {
        newErrors[key] = "Please select an answer.";
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateScore = () => {
    return questions.reduce((score, q) => {
      return section3[q.key] === q.answer ? score + 1 : score;
    }, 0);
  };

  const handleSubmit = async () => {
    if (!validate()) {
      const firstError = document.querySelector("[data-error='true']");
      firstError?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    setLoading(true);
    try {
      const score = calculateScore();
      updateSection3({ score } as any);

      await fetch("/api/exam/save-answer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId,
          section: "section3",
          answers: { ...section3, score },
        }),
      });

      await fetch("/api/exam/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, autoSubmit: false }),
      });

      setSubmitted(true);
      router.push("/complete");
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const answeredCount = questions.filter((q) => !!section3[q.key]).length;

  return (
    <main className="max-w-2xl mx-auto px-4 py-12">
      {/* Section header */}
      <div className="mb-8">
        <span className="text-xs text-blue-600 font-semibold uppercase tracking-widest">
          Section 3 of 3
        </span>
        <h1 className="text-2xl font-bold text-[#003580] mt-1">
          Mathematical Reasoning
        </h1>
        <p className="text-gray-500 text-sm mt-2 leading-relaxed">
          In the following questions, you are given several options to choose
          from. Only one option is correct. The use of calculators or mobile
          phones is strictly not allowed. Please mark your answer clearly.
        </p>

        {/* No calculator warning */}
        <div className="mt-4 bg-red-50 border border-red-200 rounded-xl p-3 
          flex items-center gap-2 text-sm text-red-700">
          <span>🚫</span>
          <span>
            Calculators and mobile phones are <strong>strictly prohibited</strong> during this section.
          </span>
        </div>
      </div>

      {/* Questions */}
      <div className="space-y-6">
        {questions.map((q, index) => {
          const selected = section3[q.key];
          const hasError = !!errors[q.key];

          return (
            <div
              key={q.key}
              data-error={hasError ? "true" : "false"}
              className={`bg-white rounded-2xl border shadow-sm p-6 transition-all
                ${hasError ? "border-red-300" : "border-gray-200"}`}
            >
              {/* Question */}
              <p className="text-sm font-semibold text-gray-800 mb-4 leading-relaxed">
                <span className="text-blue-600 mr-2">{index + 1}.</span>
                {q.question}
              </p>

              {/* Options */}
              <div className="space-y-2.5">
                {q.options.map((option) => {
                  const isSelected = selected === option.id;
                  return (
                    <label
                      key={option.id}
                      className={`flex items-center gap-3 p-3.5 rounded-xl border cursor-pointer
                        transition-all duration-150 select-none
                        ${
                          isSelected
                            ? "border-blue-500 bg-blue-50"
                            : "border-gray-200 hover:border-gray-300 bg-gray-50 hover:bg-gray-100"
                        }`}
                    >
                      {/* Custom radio circle */}
                      <div
                        className={`w-5 h-5 rounded-full border-2 flex items-center 
                          justify-center flex-shrink-0 transition-all
                          ${
                            isSelected
                              ? "border-blue-500 bg-blue-500"
                              : "border-gray-300"
                          }`}
                      >
                        {isSelected && (
                          <div className="w-2 h-2 rounded-full bg-white" />
                        )}
                      </div>

                      {/* Option label badge */}
                      <span
                        className={`text-xs font-bold w-6 flex-shrink-0
                          ${isSelected ? "text-blue-600" : "text-gray-400"}`}
                      >
                        {option.id}
                      </span>

                      {/* Option text */}
                      <span
                        className={`text-sm ${
                          isSelected ? "text-blue-800 font-medium" : "text-gray-700"
                        }`}
                      >
                        {option.text}
                      </span>

                      {/* Hidden input */}
                      <input
                        type="radio"
                        name={q.key}
                        value={option.id}
                        checked={isSelected}
                        onChange={() =>
                          updateSection3({ [q.key]: option.id } as any)
                        }
                        className="sr-only"
                      />
                    </label>
                  );
                })}
              </div>

              {hasError && (
                <p className="mt-3 text-xs text-red-500">{errors[q.key]}</p>
              )}
            </div>
          );
        })}
      </div>

      {/* Progress summary */}
      <div className="mt-8 bg-blue-50 border border-blue-100 rounded-xl p-4">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-blue-700 font-medium">Questions answered</span>
          <span className="text-blue-700 font-bold">
            {answeredCount}/{questions.length}
          </span>
        </div>
        <div className="w-full bg-blue-100 rounded-full h-2">
          <div
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${(answeredCount / questions.length) * 100}%` }}
          />
        </div>
        {answeredCount === questions.length && (
          <p className="mt-2 text-xs text-green-600 font-medium text-center">
            ✓ All questions answered — you are ready to submit.
          </p>
        )}
      </div>

      {/* Submit button */}
      <button
        onClick={handleSubmit}
        disabled={loading || submitted}
        className="mt-6 w-full bg-green-700 hover:bg-green-800 disabled:bg-gray-300
          text-white font-semibold text-base py-4 rounded-xl transition-all duration-200"
      >
        {loading
          ? "Submitting exam..."
          : submitted
          ? "Submitted ✓"
          : "Submit Exam →"}
      </button>

      <p className="text-center text-xs text-gray-400 mt-4">
        Once submitted, your exam cannot be changed. Ensure all answers are final.
      </p>
    </main>
  );
}