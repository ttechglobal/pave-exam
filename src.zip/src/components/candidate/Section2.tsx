"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useExamStore } from "@/store/examStore";

const questions = [
  {
    key: "knowledgeOfFinland",
    label: "What do you know about Finland?",
    placeholder:
      "Share what you know about Finland — its culture, climate, education system, or anything else relevant...",
  },
  {
    key: "reasonsForMoving",
    label: "What are the main reasons for wanting to move to Finland?",
    placeholder:
      "Explain your personal and professional motivations for choosing Finland...",
  },
  {
    key: "adaptationPlan",
    label: "How do you plan to adapt to living in a new country?",
    placeholder:
      "Describe the steps you would take to settle in and adjust to life in Finland...",
  },
  {
    key: "whyChooseYou",
    label: "Why should we choose you for this programme?",
    placeholder:
      "Tell us what makes you a strong candidate for this vocational qualification...",
  },
  {
    key: "workExperience",
    label:
      "Do you have any work experience in the cleaning field or customer service?",
    placeholder:
      "Describe any relevant work experience, including roles, duration, and key responsibilities...",
  },
  {
    key: "lifeSituation",
    label:
      "How does your current life situation support studying full-time abroad?",
    placeholder:
      "Explain how your family, financial, and personal circumstances support this commitment...",
  },
  {
    key: "knowledgeOfCleaning",
    label: "What do you know about professional cleaning?",
    placeholder:
      "Share your understanding of professional cleaning standards, tools, and practices...",
  },
  {
    key: "futurePlans",
    label: "What are your future plans after graduation?",
    placeholder:
      "Describe your career goals and how this qualification will help you achieve them...",
  },
  {
    key: "fiveYearPlan",
    label: "Where do you see yourself in five years?",
    placeholder:
      "Paint a picture of your personal and professional life five years from now...",
  },
] as const;

type Section2Key = (typeof questions)[number]["key"];

export default function Section2() {
  const router = useRouter();
  const { updateSection2, section2, sessionId, setCurrentSection } =
    useExamStore();
  const [errors, setErrors] = useState<Partial<Record<Section2Key, string>>>(
    {}
  );
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const newErrors: Partial<Record<Section2Key, string>> = {};
    questions.forEach(({ key, label }) => {
      if (!section2[key]?.trim()) {
        newErrors[key] = `This question is required.`;
      } else if (section2[key].trim().split(/\s+/).length < 5) {
        newErrors[key] = "Please provide a more detailed answer.";
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleComplete = async () => {
    if (!validate()) {
      // scroll to first error
      const firstError = document.querySelector("[data-error='true']");
      firstError?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    setLoading(true);
    try {
      await fetch("/api/exam/save-answer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId,
          section: "section2",
          answers: section2,
        }),
      });
      setCurrentSection(3);
      router.push("/exam/section-intro?section=3");
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const wordCount = (text: string) =>
    text.trim() === "" ? 0 : text.trim().split(/\s+/).length;

  return (
    <main className="max-w-2xl mx-auto px-4 py-12">
      {/* Section header */}
      <div className="mb-8">
        <span className="text-xs text-blue-600 font-semibold uppercase tracking-widest">
          Section 2 of 3
        </span>
        <h1 className="text-2xl font-bold text-[#003580] mt-1">
          Personal Background & Motivation
        </h1>
        <p className="text-gray-500 text-sm mt-2 leading-relaxed">
          Answer all questions honestly and in full sentences. Your responses
          will be reviewed by the admissions panel. Do not leave any question
          blank.
        </p>
      </div>

      {/* Questions */}
      <div className="space-y-6">
        {questions.map((q, index) => {
          const value = section2[q.key] ?? "";
          const count = wordCount(value);
          const hasError = !!errors[q.key];

          return (
            <div
              key={q.key}
              data-error={hasError ? "true" : "false"}
              className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6"
            >
              {/* Question label */}
              <label className="block text-sm font-semibold text-gray-800 mb-3">
                <span className="text-blue-600 mr-2">{index + 1}.</span>
                {q.label}
                <span className="text-red-500 ml-1">*</span>
              </label>

              {/* Textarea */}
              <textarea
                rows={5}
                placeholder={q.placeholder}
                value={value}
                onChange={(e) =>
                  updateSection2({ [q.key]: e.target.value } as any)
                }
                className={`w-full px-4 py-3 rounded-xl border text-sm outline-none resize-none
                  transition-all bg-gray-50 focus:bg-white focus:ring-2 focus:ring-blue-500
                  ${hasError ? "border-red-400 focus:ring-red-400" : "border-gray-200"}`}
              />

              {/* Footer row */}
              <div className="flex items-center justify-between mt-2">
                {hasError ? (
                  <p className="text-xs text-red-500">{errors[q.key]}</p>
                ) : (
                  <span />
                )}
                <span
                  className={`text-xs ml-auto ${
                    count < 5 ? "text-gray-400" : "text-green-600"
                  }`}
                >
                  {count} word{count !== 1 ? "s" : ""}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Progress summary */}
      <div className="mt-8 bg-blue-50 border border-blue-100 rounded-xl p-4">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-blue-700 font-medium">Questions answered</span>
          <span className="text-blue-700 font-bold">
            {questions.filter((q) => section2[q.key]?.trim().split(/\s+/).length >= 5).length}
            /{questions.length}
          </span>
        </div>
        <div className="w-full bg-blue-100 rounded-full h-2">
          <div
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{
              width: `${
                (questions.filter(
                  (q) => section2[q.key]?.trim().split(/\s+/).length >= 5
                ).length /
                  questions.length) *
                100
              }%`,
            }}
          />
        </div>
      </div>

      {/* Complete button */}
      <button
        onClick={handleComplete}
        disabled={loading}
        className="mt-6 w-full bg-[#003580] hover:bg-[#002a6b] disabled:bg-gray-300
          text-white font-semibold text-base py-4 rounded-xl transition-all duration-200"
      >
        {loading ? "Saving..." : "Complete Section 2 →"}
      </button>

      <p className="text-center text-xs text-gray-400 mt-4">
        You cannot return to this section once you proceed.
      </p>
    </main>
  );
}