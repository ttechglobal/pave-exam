"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useExamStore } from "@/store/examStore";
import type { Section1Answers } from "@/types";

const responsibilities = [
  "Students are responsible for their own financial planning, including tuition fees, accommodation, and living expenses throughout the duration of the programme.",
  "Students are responsible for obtaining and maintaining all required travel documents, including visas, residence permits, and health insurance valid in Finland.",
  "Students are expected to attend all classes, training sessions, and assessments punctually and consistently as required by TAKK.",
  "Students are responsible for their personal conduct, social behaviour, and adherence to Finnish laws and institutional regulations at all times.",
  "Students must proactively seek guidance from programme coordinators when facing academic, social, or personal challenges during their studies.",
  "Students are responsible for ensuring their accommodation arrangements are secured prior to arrival in Finland.",
  "Students acknowledge that failure to meet programme requirements may result in suspension or termination of their student status.",
];

export default function Section1() {
  const router = useRouter();
  const { updateSection1, section1, sessionId, setCurrentSection } = useExamStore();
  const [errors, setErrors] = useState<Partial<Record<keyof Section1Answers, string>>>({});
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const newErrors: Partial<Record<keyof Section1Answers, string>> = {};
    if (!section1.physicalHealth) {
      newErrors.physicalHealth = "Please select one option.";
    }
    if (section1.physicalHealth === "limited" && !section1.physicalLimitationDetail.trim()) {
      newErrors.physicalLimitationDetail = "Please provide details about your physical limitations.";
    }
    if (!section1.agreedToResponsibilities) {
      newErrors.agreedToResponsibilities = "You must agree to the responsibilities to proceed.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleComplete = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      await fetch("/api/exam/save-answer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId,
          section: "section1",
          answers: section1,
        }),
      });
      setCurrentSection(2);
      router.push("/exam/section-intro?section=2");
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="max-w-2xl mx-auto px-4 py-12">

      {/* Section header */}
      <div className="mb-8">
        <span className="text-xs text-blue-600 font-semibold uppercase tracking-widest">
          Section 1 of 3
        </span>
        <h1 className="text-2xl font-bold text-[#003580] mt-1">
          Health & Ability to Manage Living in Finland
        </h1>
        <p className="text-gray-500 text-sm mt-2 leading-relaxed">
          Working in professional cleaning requires you to be sufficiently fit
          and able to do physical work. Work may require that you are standing
          on your feet for long hours, walking, bending down, carrying and
          moving items. Please provide honest information below.
        </p>
      </div>

      {/* Q1 — Physical health */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 mb-6">
        <h2 className="text-sm font-semibold text-gray-800 mb-4">
          1. Please tick the option that best describes your physical condition:
          <span className="text-red-500 ml-1">*</span>
        </h2>

        <div className="space-y-3">
          {[
            {
              value: "healthy",
              label: "I am physically healthy, I have no injuries that limit physical movement.",
            },
            {
              value: "limited",
              label: "I have physical limitations and I struggle to do physical work.",
            },
          ].map((option) => (
            <label
              key={option.value}
              className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer
                transition-all duration-150
                ${section1.physicalHealth === option.value
                  ? "border-blue-500 bg-blue-50"
                  : "border-gray-200 hover:border-gray-300 bg-gray-50"
                }`}
            >
              <input
                type="radio"
                name="physicalHealth"
                value={option.value}
                checked={section1.physicalHealth === option.value}
                onChange={() =>
                  updateSection1({
                    physicalHealth: option.value as "healthy" | "limited",
                  })
                }
                className="mt-0.5 accent-blue-600"
              />
              <span className="text-sm text-gray-700">{option.label}</span>
            </label>
          ))}
        </div>

        {errors.physicalHealth && (
          <p className="mt-2 text-xs text-red-500">{errors.physicalHealth}</p>
        )}

        {/* Conditional detail box */}
        {section1.physicalHealth === "limited" && (
          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-1.5">
              Please provide more information about your physical limitations:
              <span className="text-red-500 ml-1">*</span>
            </label>
            <textarea
              rows={4}
              placeholder="Describe your physical limitations here..."
              value={section1.physicalLimitationDetail}
              onChange={(e) =>
                updateSection1({ physicalLimitationDetail: e.target.value })
              }
              className={`w-full px-4 py-3 rounded-xl border text-sm outline-none resize-none
                transition-all bg-gray-50 focus:bg-white focus:ring-2 focus:ring-blue-500
                ${errors.physicalLimitationDetail ? "border-red-400" : "border-gray-200"}`}
            />
            {errors.physicalLimitationDetail && (
              <p className="mt-1 text-xs text-red-500">
                {errors.physicalLimitationDetail}
              </p>
            )}
          </div>
        )}
      </div>

      {/* Responsibilities */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 mb-6">
        <h2 className="text-sm font-semibold text-gray-800 mb-1">
          2. Student Responsibilities Statement
        </h2>
        <p className="text-xs text-gray-500 mb-4">
          Please read the following responsibilities carefully before proceeding.
        </p>

        <div className="bg-gray-50 rounded-xl border border-gray-200 p-4 space-y-3 max-h-60 overflow-y-auto">
          {responsibilities.map((item, i) => (
            <div key={i} className="flex items-start gap-3">
              <span className="w-5 h-5 rounded-full bg-white border border-gray-300 
                text-gray-500 text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                {i + 1}
              </span>
              <p className="text-sm text-gray-600 leading-relaxed">{item}</p>
            </div>
          ))}
        </div>

        {/* Agreement checkbox */}
        <label className={`mt-4 flex items-start gap-3 p-4 rounded-xl border cursor-pointer
          transition-all duration-150
          ${section1.agreedToResponsibilities
            ? "border-blue-500 bg-blue-50"
            : "border-gray-200 hover:border-gray-300 bg-gray-50"
          }`}>
          <input
            type="checkbox"
            checked={section1.agreedToResponsibilities}
            onChange={(e) =>
              updateSection1({ agreedToResponsibilities: e.target.checked })
            }
            className="mt-0.5 w-4 h-4 accent-blue-600 flex-shrink-0"
          />
          <span className="text-sm text-gray-700">
            I have read and understood my responsibilities and I acknowledge
            that I am enrolling as a full-time student.
          </span>
        </label>

        {errors.agreedToResponsibilities && (
          <p className="mt-2 text-xs text-red-500">
            {errors.agreedToResponsibilities}
          </p>
        )}
      </div>

      {/* Complete Section Button */}
      <button
        onClick={handleComplete}
        disabled={loading}
        className="w-full bg-[#003580] hover:bg-[#002a6b] disabled:bg-gray-300
          text-white font-semibold text-base py-4 rounded-xl transition-all duration-200"
      >
        {loading ? "Saving..." : "Complete Section 1 →"}
      </button>

      <p className="text-center text-xs text-gray-400 mt-4">
        You cannot return to this section once you proceed.
      </p>

    </main>
  );
}